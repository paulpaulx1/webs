# Boilerplate
This is a barebones PERN (Postgres, Express, React, Node) boilerplate with up-to-date dependencies and a basic full-stack configuration. 

## Setup
Clone or fork & clone this repo to your local machine. Run `npm install` from inside the project directory to install the dependencies. Run `npm start` to launch the development server at `port 8000` and bundle the frontend with webpack in watch mode.
# pers
